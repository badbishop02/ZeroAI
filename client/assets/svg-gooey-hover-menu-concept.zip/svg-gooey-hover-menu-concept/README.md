# SVG Gooey Hover Menu Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/mikel301292/pen/dMYRYZ](https://codepen.io/mikel301292/pen/dMYRYZ).

Uses SVG path manipulation based on mouse position  to 'chase' the user's position